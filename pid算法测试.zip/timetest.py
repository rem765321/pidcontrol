import time
time.time()
print(time.time())
time.sleep(2)
print(time.time())


print("时间",time.ctime())

# 1642348585.668144  #1970纪元后经过的浮点秒数
# 1642348587.6698427
# 时间 Sun Jan 16 23:56:27 2022